
import React, { useState, useEffect, useCallback } from 'react';
import { INDICATORS } from './constants';
import { RiskIndicator, AnalysisSummary, RiskLevel } from './types';
import { GeminiService } from './services/geminiService';
import MetricCard from './components/MetricCard';
import BurryTerminal from './components/BurryTerminal';
import GaugeChart from './components/GaugeChart';

const App: React.FC = () => {
  const [indicators, setIndicators] = useState<RiskIndicator[]>(INDICATORS);
  const [analysis, setAnalysis] = useState<AnalysisSummary | null>(null);
  const [loading, setLoading] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<string>(new Date().toLocaleTimeString());

  const runAnalysis = useCallback(async () => {
    setLoading(true);
    const service = new GeminiService();
    const result = await service.analyzeRisk(indicators);
    if (result) {
      setAnalysis(result);
    }
    setLoading(false);
    setLastUpdate(new Date().toLocaleTimeString());
  }, [indicators]);

  useEffect(() => {
    runAnalysis();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const randomizeData = () => {
    setIndicators(prev => prev.map(ind => ({
      ...ind,
      value: Math.min(100, Math.max(0, ind.value + (Math.random() * 20 - 10)))
    })));
  };

  return (
    <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-12 py-10 min-h-screen">
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-10 mb-16">
        <div className="relative">
          <div className="flex items-center gap-3 mb-4">
            <span className="bg-red-500/20 text-red-500 text-[11px] font-black px-4 py-1.5 rounded-full border border-red-500/30 tracking-[0.2em] animate-pulse uppercase">
              LIVE CRISIS SCANNER
            </span>
          </div>
          <h1 className="text-7xl font-black tracking-tighter text-white flex items-center gap-4">
            BURRY<span className="text-red-500">SIGNAL</span>
          </h1>
          <p className="text-slate-400 mt-5 max-w-2xl text-xl font-light leading-relaxed">
            비관적 직관의 알고리즘화. <span className="text-blue-400 font-medium">부자들의 행동 패턴</span>과 <span className="text-red-400 font-medium">시스템의 미세한 균열</span>을 감지하여 다음 시장 붕괴를 예견합니다.
          </p>
        </div>
        
        <div className="flex flex-col items-end gap-6 bg-white/5 p-8 rounded-[2rem] border border-white/10 backdrop-blur-3xl shadow-2xl">
          <div className="text-right">
            <div className="text-slate-500 text-[10px] uppercase font-mono tracking-[0.3em] mb-2">Network Sync Time</div>
            <div className="text-4xl font-black mono text-slate-100 tracking-tighter">{lastUpdate}</div>
          </div>
          <button 
            onClick={() => { randomizeData(); runAnalysis(); }}
            disabled={loading}
            className={`w-full px-10 py-5 rounded-2xl font-black text-xs tracking-[0.3em] uppercase transition-all flex items-center justify-center gap-4 ${
              loading 
              ? 'bg-slate-800 text-slate-600 cursor-not-allowed' 
              : 'bg-red-600 hover:bg-red-500 text-white shadow-[0_15px_30px_rgba(220,38,38,0.3)] hover:-translate-y-1 active:translate-y-0'
            }`}
          >
            {loading ? 'ANALYZING THREATS...' : 'RUN DEEP ANALYSIS'}
          </button>
        </div>
      </header>

      {/* 
          Main Analysis Top Section 
          - Laptop (lg): 좌측 게이지(8), 우측 적층(4)
          - Mobile (default): 수직 적층 (grid-cols-1)
      */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-10 mb-20 items-stretch">
        <div className="lg:col-span-8 flex items-center justify-center">
          <GaugeChart 
            score={analysis?.score || 0} 
            label={analysis?.simpleStatus || '시스템 데이터 로딩 중...'} 
          />
        </div>
        
        <div className="lg:col-span-4 flex flex-col gap-5 justify-between">
          {[
            { level: 'STABLE', range: '0-30%', desc: '경제의 평온한 상태. 비정상적 징후 감지되지 않음.', color: 'text-green-500', bg: 'bg-green-500/5', border: 'border-green-500/20' },
            { level: 'WARNING', range: '31-60%', desc: '미세 균열 발생. 엘리트 계층의 자산 이동 징후 포착.', color: 'text-amber-500', bg: 'bg-amber-500/5', border: 'border-amber-500/20' },
            { level: 'CRISIS', range: '61-80%', desc: '시스템 붕괴 임계점 도달. 시장 전반의 공포 확산 중.', color: 'text-orange-600', bg: 'bg-orange-600/5', border: 'border-orange-600/20' },
            { level: 'CATASTROPHIC', range: '81-100%', desc: '총체적 붕괴 시작. 즉각적인 헤징 및 자산 보호 권장.', color: 'text-red-600', bg: 'bg-red-600/5', border: 'border-red-600/20' },
          ].map((item) => (
            <div key={item.level} className={`p-8 rounded-[1.5rem] border ${item.border} flex flex-col justify-center transition-all duration-500 hover:bg-white/10 ${item.bg} flex-1 relative overflow-hidden group shadow-lg`}>
              <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                 <div className={`text-4xl font-black uppercase ${item.color}`}>{item.level[0]}</div>
              </div>
              <div className={`text-xl font-black mb-2 flex items-center justify-between ${item.color} tracking-tighter`}>
                <span>{item.level}</span>
                <span className="text-xs opacity-60 font-mono tracking-widest">{item.range}</span>
              </div>
              <div className="text-sm text-slate-400 leading-relaxed">{item.desc}</div>
              {analysis?.overallRisk === item.level && (
                <div className="mt-4 flex items-center gap-3">
                  <div className="w-2.5 h-2.5 rounded-full bg-white animate-ping"></div>
                  <span className="text-[10px] font-black bg-white/20 text-white px-4 py-1.5 rounded-full uppercase tracking-[0.2em] shadow-xl">
                    CURRENT STATE DETECTED
                  </span>
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      <main className="space-y-24">
        {/* Main Indicators Grid */}
        <section>
          <div className="flex items-center justify-between mb-10">
            <h2 className="text-xs font-mono tracking-[0.5em] uppercase text-slate-500">Unconventional_Risk_Telemetry</h2>
            <div className="h-px flex-1 bg-gradient-to-r from-transparent via-white/10 to-transparent mx-12"></div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {indicators.map((indicator) => (
              <MetricCard key={indicator.id} indicator={indicator} />
            ))}
          </div>
        </section>

        {/* AI Analysis Section */}
        <section className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2">
             <div className="flex items-center gap-4 mb-8">
               <h2 className="text-xs font-mono tracking-[0.5em] uppercase text-slate-500">Scion_AI_Deep_Scan</h2>
               <div className="flex-1 h-px bg-white/10"></div>
             </div>
            <BurryTerminal analysis={analysis} loading={loading} />
          </div>
          
          <div className="space-y-10">
            <div className="glass rounded-[2rem] p-10 border-red-500/20 bg-gradient-to-br from-red-500/10 to-transparent shadow-2xl">
              <h3 className="text-red-500 font-black mb-8 flex items-center gap-4 uppercase tracking-widest text-sm">
                <span className="flex h-3 w-3 relative">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                </span>
                실시간 위험 감지 로그
              </h3>
              <div className="space-y-8">
                <div className="p-6 bg-black/40 rounded-2xl border border-white/5 shadow-inner">
                  <div className="text-[10px] text-slate-500 mb-2 font-mono uppercase tracking-widest">Contagion Factor (R₀)</div>
                  <div className="text-4xl font-black mono text-amber-500 tracking-tighter">1.84 <span className="text-xs font-normal text-slate-500 ml-2 tracking-normal">CRITICAL</span></div>
                </div>
                <div className="p-6 bg-black/40 rounded-2xl border border-white/5 shadow-inner">
                  <div className="text-[10px] text-slate-500 mb-2 font-mono uppercase tracking-widest">Liquidity Obfuscation</div>
                  <div className="text-4xl font-black mono text-red-500 tracking-tighter">92% <span className="text-xs font-normal text-slate-500 ml-2 tracking-normal">DANGER</span></div>
                </div>
                <div className="pt-6 text-sm text-slate-400 leading-relaxed italic border-t border-white/10">
                  "모두가 주가 지수만 보고 있을 때, 저는 실리콘밸리의 이혼 서류와 런던의 중고 롤렉스 매물을 봅니다. 진짜 정보는 그곳에 있습니다."
                </div>
              </div>
            </div>

            <div className="glass rounded-[2rem] p-10 border-blue-500/20 bg-blue-500/5 shadow-2xl">
               <h3 className="text-blue-400 font-black mb-8 uppercase tracking-[0.3em] text-sm">보조 데이터 스트림</h3>
               <div className="space-y-5 text-xs font-mono">
                 <div className="flex justify-between items-center py-3 border-b border-white/5">
                   <span className="text-slate-500">부실 채권 발행 속도</span>
                   <span className="text-red-400 font-bold tracking-widest">+18.5%</span>
                 </div>
                 <div className="flex justify-between items-center py-3 border-b border-white/5">
                   <span className="text-slate-500">최상위층 가계 부채</span>
                   <span className="text-amber-400 font-bold tracking-widest">DANGER</span>
                 </div>
                 <div className="flex justify-between items-center py-3 border-b border-white/5">
                   <span className="text-slate-500">연준 의사록 불투명도</span>
                   <span className="text-red-400 font-bold tracking-widest">MAX</span>
                 </div>
                 <div className="flex justify-between items-center py-3">
                   <span className="text-slate-500">내부자 현금 비중</span>
                   <span className="text-green-400 font-bold tracking-widest">HISTORIC HIGH</span>
                 </div>
               </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="mt-40 py-16 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-8 text-slate-600 text-[11px] tracking-[0.4em] uppercase font-mono">
        <div>© 2024 SCION_SIGNAL_INTEL - NOT FINANCIAL ADVICE</div>
        <div className="flex gap-12">
          <span>LATENCY: 12ms</span>
          <span>UPTIME: 99.9%</span>
          <span>SECURED: AES-4096</span>
        </div>
      </footer>
    </div>
  );
};

export default App;
