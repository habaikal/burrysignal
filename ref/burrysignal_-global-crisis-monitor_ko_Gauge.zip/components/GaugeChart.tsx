
import React from 'react';

interface GaugeChartProps {
  score: number;
  label: string;
}

const GaugeChart: React.FC<GaugeChartProps> = ({ score, label }) => {
  const strokeWidth = 14;
  const normalizedScore = Math.min(Math.max(score, 0), 100);
  
  // 바늘 각도 계산: 0%일 때 0도(왼쪽 시작점), 100%일 때 180도(오른쪽 끝점)
  // SVG 좌표계에서 (20, 100) 위치에서 시작하여 (100, 100)을 중심으로 회전
  const needleRotation = (normalizedScore / 100) * 180;

  const getStatusColor = (s: number) => {
    if (s <= 30) return '#10b981'; // Green (Stable)
    if (s <= 60) return '#f59e0b'; // Amber (Warning)
    if (s <= 80) return '#ea580c'; // Orange (Crisis)
    return '#ef4444'; // Red (Catastrophic)
  };

  return (
    <div className="flex flex-col items-center justify-between p-10 glass rounded-[2.5rem] border-white/5 relative overflow-hidden h-full w-full shadow-2xl">
      <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-green-500 via-yellow-500 to-red-500 opacity-30"></div>
      
      {/* 게이지 본체: 기존보다 1.5~2배 확대 느낌을 위해 max-width 상향 및 padding 조정 */}
      <div className="relative w-full max-w-[500px] flex flex-col items-center flex-1 justify-center">
        <svg viewBox="0 0 200 140" className="w-full h-auto drop-shadow-[0_0_15px_rgba(0,0,0,0.5)]">
          <defs>
            <linearGradient id="gaugeGradientMain" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#10b981" />
              <stop offset="30%" stopColor="#f59e0b" />
              <stop offset="65%" stopColor="#ea580c" />
              <stop offset="100%" stopColor="#ef4444" />
            </linearGradient>
            <filter id="needleGlow">
              <feGaussianBlur stdDeviation="1.5" result="blur"/>
              <feComposite in="SourceGraphic" in2="blur" operator="over"/>
            </filter>
          </defs>
          
          {/* Base Track (Background) */}
          <path
            d="M 20 100 A 80 80 0 0 1 180 100"
            fill="none"
            stroke="#111827"
            strokeWidth={strokeWidth}
            strokeLinecap="round"
          />
          
          {/* Progress Track (Colored) */}
          <path
            d="M 20 100 A 80 80 0 0 1 180 100"
            fill="none"
            stroke="url(#gaugeGradientMain)"
            strokeWidth={strokeWidth}
            strokeLinecap="round"
            strokeDasharray="251.32"
            strokeDashoffset={251.32 - (normalizedScore / 100) * 251.32}
            className="transition-all duration-1000 ease-out"
          />

          {/* Scale Markers */}
          <text x="20" y="122" fontSize="6" fill="#4b5563" textAnchor="middle" className="font-mono font-bold tracking-tighter">0% SAFE</text>
          <text x="100" y="32" fontSize="6" fill="#4b5563" textAnchor="middle" className="font-mono font-bold">50%</text>
          <text x="180" y="122" fontSize="6" fill="#4b5563" textAnchor="middle" className="font-mono font-bold tracking-tighter">100% CRISIS</text>

          {/* Needle (정확한 위치 가리키도록 수정) */}
          <g transform={`rotate(${needleRotation}, 100, 100)`} className="transition-transform duration-1000 cubic-bezier(0.34, 1.56, 0.64, 1)">
            <line 
              x1="20" y1="100" x2="100" y2="100" 
              stroke="#ffffff" 
              strokeWidth="3" 
              strokeLinecap="round"
              filter="url(#needleGlow)"
            />
            <circle cx="100" cy="100" r="6" fill="#ffffff" />
            <circle cx="100" cy="100" r="2.5" fill="#020617" />
          </g>
        </svg>

        {/* 텍스트 정보: 바늘과 겹치지 않도록 위치 및 여백 최적화 */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pt-10 pointer-events-none">
          <div className="text-7xl font-black mono text-white drop-shadow-[0_4px_4px_rgba(0,0,0,0.8)] mb-3">
            {Math.round(score)}
          </div>
          <div 
            className="px-6 py-2 rounded-xl bg-black/60 border border-white/10 backdrop-blur-xl text-center shadow-2xl"
          >
            <div className="text-[10px] uppercase font-mono tracking-[0.3em] text-slate-500 mb-1">Current Status</div>
            <div className="text-xs font-black uppercase tracking-widest leading-tight max-w-[200px]" style={{ color: getStatusColor(score) }}>
              {label}
            </div>
          </div>
        </div>
      </div>

      {/* 하단 보조 정보 영역 */}
      <div className="mt-8 grid grid-cols-2 gap-6 w-full max-w-[450px]">
        <div className="text-center p-4 bg-white/5 rounded-2xl border border-white/5 flex flex-col justify-center">
          <div className="text-[10px] text-slate-500 uppercase tracking-[0.2em] mb-1 font-mono">Prev Close</div>
          <div className="text-lg font-bold text-slate-300 mono">12 <span className="text-[10px] font-normal opacity-50 uppercase">(Stable)</span></div>
        </div>
        <div className="text-center p-4 bg-white/5 rounded-2xl border border-white/5 flex flex-col justify-center">
          <div className="text-[10px] text-slate-500 uppercase tracking-[0.2em] mb-1 font-mono">1 Week Ago</div>
          <div className="text-lg font-bold text-slate-300 mono">45 <span className="text-[10px] font-normal opacity-50 uppercase">(Warning)</span></div>
        </div>
      </div>
    </div>
  );
};

export default GaugeChart;
