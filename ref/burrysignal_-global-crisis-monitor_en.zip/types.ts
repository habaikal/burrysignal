
export enum RiskLevel {
  STABLE = 'STABLE',
  WARNING = 'WARNING',
  CRISIS = 'CRISIS',
  CATASTROPHIC = 'CATASTROPHIC'
}

export interface RiskIndicator {
  id: string;
  title: string;
  category: string;
  description: string;
  value: number; // 0 to 100
  trend: 'up' | 'down' | 'neutral';
  color: string;
  icon: string;
  logic: string;
}

export interface AnalysisSummary {
  overallRisk: RiskLevel;
  score: number;
  executiveSummary: string;
  topThreats: string[];
  contrarianInsight: string;
  strategies: string[]; // New field for response strategies
}
