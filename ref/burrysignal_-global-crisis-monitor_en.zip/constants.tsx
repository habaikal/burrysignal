
import React from 'react';
import { RiskIndicator } from './types';

export const INDICATORS: RiskIndicator[] = [
  {
    id: 'ecfi',
    title: 'Elite Consumption Fracture',
    category: 'Elite Psychology',
    description: 'Secondary market surge in high-end luxury assets (Patek Philippe, Supercars, Jets) with heavy discounts.',
    value: 78,
    trend: 'up',
    color: '#ef4444',
    icon: '💎',
    logic: 'The rich collapse first, but silently. Watch the "distress sales" of those who know the system is failing.'
  },
  {
    id: 'lds',
    title: 'Linguistic Drift Signal',
    category: 'Financial Semantics',
    description: 'Transition of jargon from "Growth" to "Resilience" and "Liquidity" in IB/Hedge Fund executive memos.',
    value: 85,
    trend: 'up',
    color: '#f97316',
    icon: '🗣️',
    logic: 'Adjectives decrease, conditionals increase. Precision replaces optimism before a storm.'
  },
  {
    id: 'r0',
    title: 'Financial R₀ Index',
    category: 'Contagion Dynamics',
    description: 'Viral spread coefficient of counterparty failure across systemic institutions.',
    value: 62,
    trend: 'up',
    color: '#fbbf24',
    icon: '🦠',
    logic: 'If R₀ > 1.5, a single default triggers a cascade that cannot be contained by traditional liquidity injections.'
  },
  {
    id: 'rcv',
    title: 'Risk Camouflage Velocity',
    category: 'Structural Complexity',
    description: 'Rate of new complex instrument issuance and exponential growth in regulatory filing length.',
    value: 91,
    trend: 'up',
    color: '#ef4444',
    icon: '📄',
    logic: 'Risk hides in complexity. When you cant explain the product in one sentence, the crash is near.'
  },
  {
    id: 'idi',
    title: 'Insider Divergence Index',
    category: 'Information Asymmetry',
    description: 'Delta between public "All is well" statements and private personal asset liquidation/hedging.',
    value: 74,
    trend: 'neutral',
    color: '#f97316',
    icon: '🎭',
    logic: 'Watch the feet, not the mouth. If they talk long but trade short, trust the trade.'
  },
  {
    id: 'hmsi',
    title: 'Elite Mental Stress',
    category: 'Unstructured Data',
    description: 'Surge in sleep-aid prescriptions and divorce filings in high-net-worth zip codes (NYC, Silicon Valley).',
    value: 45,
    trend: 'down',
    color: '#10b981',
    icon: '🧠',
    logic: 'Crisis starts in the mind. Fear manifests in biological and social instability before it hits the tape.'
  },
  {
    id: 'scbi',
    title: 'Silent Central Bank',
    category: 'Monetary Policy',
    description: 'Inverse correlation between transparency and crisis proximity. Longer time-horizon rhetoric used as delay.',
    value: 82,
    trend: 'up',
    color: '#ef4444',
    icon: '🏦',
    logic: 'When central bankers stop answering questions and start quoting "Long Term Stability", the exit is locked.'
  }
];
