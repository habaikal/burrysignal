
import { GoogleGenAI, Type } from "@google/genai";
import { RiskIndicator } from "../types";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async analyzeRisk(indicators: RiskIndicator[]) {
    const prompt = `
      Act as Michael Burry. Analyze the following 7 unconventional global crisis indicators.
      Data: ${JSON.stringify(indicators.map(i => ({ title: i.title, value: i.value, logic: i.logic })))}

      1. Provide a deep, contrarian summary of the global situation. Be cynical, data-driven, and sharp.
      2. Identify the specific 'Fracture Point' where the system collapses.
      3. CRITICAL: Suggest 3-4 specific 'Counter-Move Strategies' (Response Strategies) in the style of Scion Capital. 
         Think: Credit Default Swaps, specific sector shorts, tail-risk hedging, or idiosyncratic long positions.
      
      Respond in the language the user is using (Korean), but keep the financial jargon sharp.
    `;

    try {
      const response = await this.ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              overallRisk: { type: Type.STRING, description: "One of: STABLE, WARNING, CRISIS, CATASTROPHIC" },
              score: { type: Type.NUMBER, description: "Overall 0-100 risk score" },
              executiveSummary: { type: Type.STRING },
              topThreats: { type: Type.ARRAY, items: { type: Type.STRING } },
              contrarianInsight: { type: Type.STRING },
              strategies: { 
                type: Type.ARRAY, 
                items: { type: Type.STRING },
                description: "Actionable Burry-style response strategies"
              }
            },
            required: ["overallRisk", "score", "executiveSummary", "topThreats", "contrarianInsight", "strategies"]
          }
        }
      });

      return JSON.parse(response.text);
    } catch (error) {
      console.error("Gemini Analysis Error:", error);
      return null;
    }
  }
}
