
import React, { useState, useEffect, useCallback } from 'react';
import { INDICATORS } from './constants';
import { RiskIndicator, AnalysisSummary, RiskLevel } from './types';
import { GeminiService } from './services/geminiService';
import MetricCard from './components/MetricCard';
import BurryTerminal from './components/BurryTerminal';

const App: React.FC = () => {
  const [indicators, setIndicators] = useState<RiskIndicator[]>(INDICATORS);
  const [analysis, setAnalysis] = useState<AnalysisSummary | null>(null);
  const [loading, setLoading] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<string>(new Date().toLocaleTimeString());

  const runAnalysis = useCallback(async () => {
    setLoading(true);
    const service = new GeminiService();
    const result = await service.analyzeRisk(indicators);
    if (result) {
      setAnalysis(result);
    }
    setLoading(false);
    setLastUpdate(new Date().toLocaleTimeString());
  }, [indicators]);

  useEffect(() => {
    runAnalysis();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const randomizeData = () => {
    setIndicators(prev => prev.map(ind => ({
      ...ind,
      value: Math.min(100, Math.max(0, ind.value + (Math.random() * 10 - 5)))
    })));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 min-h-screen">
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <span className="bg-red-500/20 text-red-500 text-[10px] font-bold px-2 py-0.5 rounded border border-red-500/30 tracking-tighter animate-pulse uppercase">
              Live Monitoring Active
            </span>
            <span className="text-slate-500 text-xs font-mono">TELEMETRY_SOURCE: UNCONVENTIONAL_ALPHA</span>
          </div>
          <h1 className="text-5xl font-black tracking-tighter text-slate-100 flex items-center gap-4">
            BURRY<span className="text-red-500">SIGNAL</span>
          </h1>
          <p className="text-slate-400 mt-2 max-w-xl text-lg font-light">
            Autonomous global crisis detection platform utilizing high-income psychological drift and structural camouflage metrics.
          </p>
        </div>
        
        <div className="flex items-center gap-6">
          <div className="text-right">
            <div className="text-slate-500 text-[10px] uppercase font-mono tracking-widest mb-1">Last Update</div>
            <div className="text-2xl font-bold mono text-slate-200">{lastUpdate}</div>
          </div>
          <button 
            onClick={() => { randomizeData(); runAnalysis(); }}
            disabled={loading}
            className={`px-8 py-4 rounded-xl font-bold text-sm tracking-widest uppercase transition-all flex items-center gap-3 ${
              loading 
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed' 
              : 'bg-red-600 hover:bg-red-500 text-white shadow-lg shadow-red-900/40 active:scale-95'
            }`}
          >
            {loading ? 'Processing...' : 'Recalculate Probability'}
            {!loading && (
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
            )}
          </button>
        </div>
      </header>

      <main className="space-y-12">
        {/* Main Indicators Grid */}
        <section>
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-sm font-mono tracking-[0.3em] uppercase opacity-40">Innovation_Metrics_Matrix</h2>
            <div className="h-px flex-1 bg-gradient-to-r from-transparent via-white/10 to-transparent mx-8"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {indicators.map((indicator) => (
              <MetricCard key={indicator.id} indicator={indicator} />
            ))}
          </div>
        </section>

        {/* AI Analysis Section */}
        <section className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <BurryTerminal analysis={analysis} loading={loading} />
          </div>
          
          <div className="space-y-8">
            <div className="glass rounded-2xl p-6 border-red-500/20 bg-red-500/5">
              <h3 className="text-red-500 font-bold mb-4 flex items-center gap-2">
                <span className="animate-ping w-2 h-2 rounded-full bg-red-500 inline-block"></span>
                SYSTEMIC_FRACTURE_WARNING
              </h3>
              <div className="space-y-4">
                <div className="p-4 bg-white/5 rounded-lg border border-white/5">
                  <div className="text-[10px] text-slate-500 mb-1">CONTAGION_RISK (R₀)</div>
                  <div className="text-2xl font-bold mono text-amber-500">1.84 <span className="text-xs font-normal text-slate-400">EXPONENTIAL</span></div>
                </div>
                <div className="p-4 bg-white/5 rounded-lg border border-white/5">
                  <div className="text-[10px] text-slate-500 mb-1">LIQUIDITY_CAMOUFLAGE</div>
                  <div className="text-2xl font-bold mono text-red-500">CRITICAL <span className="text-xs font-normal text-slate-400">92% MATCH</span></div>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed italic">
                  "Everyone is looking at the stock prices. No one is looking at the divorce rates of the fund managers or the used Ferrari inventory in Greenwich."
                </p>
              </div>
            </div>

            <div className="glass rounded-2xl p-6 border-blue-500/20 bg-blue-500/5">
               <h3 className="text-blue-400 font-bold mb-4">DATA_STREAMS</h3>
               <div className="space-y-2 text-[10px] font-mono opacity-60">
                 <div className="flex justify-between"><span>SEC_FILING_LENGTH</span><span className="text-red-400">+14.2%</span></div>
                 <div className="flex justify-between"><span>ROLEX_SUBMARINER_PREMIUM</span><span className="text-green-400">-22.8%</span></div>
                 <div className="flex justify-between"><span>WORD_COUNT_RESILIENCE</span><span className="text-red-400">MAX_PEAK</span></div>
                 <div className="flex justify-between"><span>INSIDER_CASH_RATIO</span><span className="text-amber-400">ATH</span></div>
               </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="mt-20 py-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4 text-slate-600 text-[10px] tracking-widest uppercase font-mono">
        <div>© 2024 SCION_SIGNAL_INTEL - NOT FINANCIAL ADVICE</div>
        <div className="flex gap-8">
          <span>LATENCY: 24MS</span>
          <span>UPTIME: 99.98%</span>
          <span>SECURITY: AES-4096-ECC</span>
        </div>
      </footer>
    </div>
  );
};

export default App;
