
import React, { useState, useEffect, useRef } from 'react';
import { AnalysisSummary } from '../types';

interface BurryTerminalProps {
  analysis: AnalysisSummary | null;
  loading: boolean;
}

const BurryTerminal: React.FC<BurryTerminalProps> = ({ analysis, loading }) => {
  const [displayText, setDisplayText] = useState('');
  const [index, setIndex] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (analysis?.executiveSummary) {
      setDisplayText('');
      setIndex(0);
    }
  }, [analysis]);

  useEffect(() => {
    if (analysis?.executiveSummary && index < analysis.executiveSummary.length) {
      const timeout = setTimeout(() => {
        setDisplayText(prev => prev + analysis.executiveSummary[index]);
        setIndex(prev => prev + 1);
        if (scrollRef.current) {
          scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
      }, 5); // Speed up slightly for better UX with more content
      return () => clearTimeout(timeout);
    }
  }, [analysis, index]);

  return (
    <div className="glass rounded-2xl border-white/10 overflow-hidden flex flex-col h-[600px]">
      <div className="bg-white/5 px-4 py-2 border-b border-white/10 flex items-center justify-between">
        <div className="flex gap-1.5">
          <div className="w-3 h-3 rounded-full bg-red-500/50"></div>
          <div className="w-3 h-3 rounded-full bg-yellow-500/50"></div>
          <div className="w-3 h-3 rounded-full bg-green-500/50"></div>
        </div>
        <div className="text-[10px] font-mono opacity-50 tracking-widest uppercase">
          Burry_DeepScan_v4.0_Alpha.exe
        </div>
      </div>
      
      <div ref={scrollRef} className="flex-1 p-6 font-mono text-sm leading-relaxed overflow-y-auto space-y-8 custom-scrollbar">
        {loading ? (
          <div className="flex flex-col items-center justify-center h-full text-blue-400 animate-pulse">
            <span className="text-lg">FRACTURE ANALYSIS IN PROGRESS...</span>
            <span className="text-xs mt-2">Correlating Semantic Drift with Leverage Cycles</span>
          </div>
        ) : analysis ? (
          <>
            <div className="border-l-2 border-blue-500/30 pl-4">
              <span className="text-blue-400 block text-xs mb-1 uppercase tracking-tighter"># SYSTEM_STATUS</span>
              <div className={`text-2xl font-bold ${
                analysis.overallRisk === 'CATASTROPHIC' || analysis.overallRisk === 'CRISIS' 
                ? 'text-red-500' : 'text-amber-500'
              }`}>
                {analysis.overallRisk} // SCORE: {analysis.score}
              </div>
            </div>

            <div>
              <span className="text-blue-400 block text-xs mb-1 uppercase tracking-tighter"># EXECUTIVE_SUMMARY</span>
              <p className="text-slate-300">{displayText}<span className="animate-pulse">_</span></p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white/5 p-4 rounded-xl border border-white/5">
                <span className="text-blue-400 block text-xs mb-2 uppercase tracking-tighter"># THREAT_VECTORS</span>
                <ul className="space-y-1">
                  {analysis.topThreats.map((threat, i) => (
                    <li key={i} className="text-red-400/80 flex gap-2 text-xs">
                      <span className="opacity-40">[{i+1}]</span> {threat}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="bg-amber-500/5 p-4 rounded-xl border border-amber-500/10">
                <span className="text-amber-400 block text-xs mb-2 uppercase tracking-tighter"># CONTRARIAN_INSIGHT</span>
                <p className="text-amber-200/90 italic text-xs leading-relaxed">
                  "{analysis.contrarianInsight}"
                </p>
              </div>
            </div>

            <div className="bg-red-500/10 p-6 rounded-xl border border-red-500/20">
              <span className="text-red-500 block text-xs mb-4 font-bold uppercase tracking-[0.2em]"># STRATEGIC_COUNTER_MOVES_REQUIRED</span>
              <div className="grid grid-cols-1 gap-4">
                {analysis.strategies.map((strategy, i) => (
                  <div key={i} className="flex gap-4 items-start group">
                    <div className="w-8 h-8 rounded bg-red-500/20 flex items-center justify-center text-red-500 font-bold shrink-0 text-xs">
                      {i + 1}
                    </div>
                    <p className="text-slate-200 text-sm leading-snug group-hover:text-white transition-colors">
                      {strategy}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </>
        ) : (
          <div className="text-slate-600 italic">Terminal awaiting telemetry data...</div>
        )}
      </div>
      
      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 10px; }
      `}</style>
    </div>
  );
};

export default BurryTerminal;
