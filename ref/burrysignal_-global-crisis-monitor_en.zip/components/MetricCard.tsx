
import React from 'react';
import { RiskIndicator } from '../types';

interface MetricCardProps {
  indicator: RiskIndicator;
}

const MetricCard: React.FC<MetricCardProps> = ({ indicator }) => {
  return (
    <div className="glass-card rounded-2xl p-6 relative overflow-hidden group">
      {/* Background glow */}
      <div 
        className="absolute top-0 right-0 w-32 h-32 blur-[60px] opacity-20 transition-all group-hover:opacity-40"
        style={{ backgroundColor: indicator.color }}
      />
      
      <div className="flex justify-between items-start mb-4">
        <div>
          <span className="text-2xl mb-2 block">{indicator.icon}</span>
          <h3 className="text-lg font-bold text-slate-100 tracking-tight">{indicator.title}</h3>
          <p className="text-xs font-medium uppercase tracking-widest opacity-50 mb-2">{indicator.category}</p>
        </div>
        <div className="text-right">
          <span className="text-2xl font-bold mono" style={{ color: indicator.color }}>
            {indicator.value}%
          </span>
          <div className="text-[10px] opacity-60">THRESHOLD</div>
        </div>
      </div>

      <p className="text-sm text-slate-400 leading-relaxed mb-6 h-12 overflow-hidden">
        {indicator.description}
      </p>

      <div className="w-full bg-slate-800/50 rounded-full h-1.5 mb-4 overflow-hidden">
        <div 
          className="h-full rounded-full transition-all duration-1000"
          style={{ width: `${indicator.value}%`, backgroundColor: indicator.color }}
        />
      </div>

      <div className="flex items-center gap-2 text-[10px] text-slate-500 font-mono">
        <span className="px-2 py-0.5 rounded border border-white/10">BURRY_LOGIC</span>
        <span className="truncate italic">"{indicator.logic}"</span>
      </div>
    </div>
  );
};

export default MetricCard;
