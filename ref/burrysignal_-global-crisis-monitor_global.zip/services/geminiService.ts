
import { GoogleGenAI, Type } from "@google/genai";
import { RiskIndicator, Language } from "../types";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async analyzeRisk(indicators: RiskIndicator[], lang: Language = 'en') {
    const langName = lang === 'ko' ? 'Korean' : 'English';
    const prompt = `
      Act as Michael Burry. Analyze the following 7 unconventional global crisis indicators.
      Data: ${JSON.stringify(indicators.map(i => ({ title: i.title[lang], value: i.value, logic: i.logic[lang] })))}

      1. Provide a deep, contrarian summary in ${langName}.
      2. Identify the 'Fracture Point' in ${langName}.
      3. Suggest 3-4 specific 'Counter-Move Strategies' in ${langName}.
      4. CRITICAL: Provide a "simpleStatus" - a one-sentence summary for a non-expert that captures the urgency in ${langName}.
      5. The output MUST be in ${langName}.
    `;

    try {
      const response = await this.ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              overallRisk: { type: Type.STRING },
              score: { type: Type.NUMBER },
              simpleStatus: { type: Type.STRING, description: `One sentence summary for non-experts in ${langName}` },
              executiveSummary: { type: Type.STRING },
              topThreats: { type: Type.ARRAY, items: { type: Type.STRING } },
              contrarianInsight: { type: Type.STRING },
              strategies: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["overallRisk", "score", "simpleStatus", "executiveSummary", "topThreats", "contrarianInsight", "strategies"]
          }
        }
      });

      return JSON.parse(response.text);
    } catch (error) {
      console.error("Gemini Analysis Error:", error);
      return null;
    }
  }
}
