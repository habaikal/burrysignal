
export enum RiskLevel {
  STABLE = 'STABLE',
  WARNING = 'WARNING',
  CRISIS = 'CRISIS',
  CATASTROPHIC = 'CATASTROPHIC'
}

export interface RiskIndicator {
  id: string;
  title: string;
  category: string;
  description: string;
  simpleMeaning: string; // 일반인을 위한 쉬운 의미
  value: number; 
  trend: 'up' | 'down' | 'neutral';
  color: string;
  icon: string;
  logic: string;
}

export interface AnalysisSummary {
  overallRisk: RiskLevel;
  score: number;
  simpleStatus: string; // 한 줄 상황 요약
  executiveSummary: string;
  topThreats: string[];
  contrarianInsight: string;
  strategies: string[];
}
