
import { GoogleGenAI, Type } from "@google/genai";
import { RiskIndicator } from "../types";

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
  }

  async analyzeRisk(indicators: RiskIndicator[]) {
    const prompt = `
      Act as Michael Burry. Analyze the following 7 unconventional global crisis indicators.
      Data: ${JSON.stringify(indicators.map(i => ({ title: i.title, value: i.value, logic: i.logic })))}

      1. Provide a deep, contrarian summary in Korean.
      2. Identify the 'Fracture Point'.
      3. Suggest 3-4 specific 'Counter-Move Strategies'.
      4. CRITICAL: Provide a "simpleStatus" - a one-sentence summary for a non-expert that captures the urgency.
    `;

    try {
      const response = await this.ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              overallRisk: { type: Type.STRING },
              score: { type: Type.NUMBER },
              simpleStatus: { type: Type.STRING, description: "One sentence summary for non-experts" },
              executiveSummary: { type: Type.STRING },
              topThreats: { type: Type.ARRAY, items: { type: Type.STRING } },
              contrarianInsight: { type: Type.STRING },
              strategies: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["overallRisk", "score", "simpleStatus", "executiveSummary", "topThreats", "contrarianInsight", "strategies"]
          }
        }
      });

      return JSON.parse(response.text);
    } catch (error) {
      console.error("Gemini Analysis Error:", error);
      return null;
    }
  }
}
