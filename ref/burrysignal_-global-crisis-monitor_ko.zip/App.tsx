
import React, { useState, useEffect, useCallback } from 'react';
import { INDICATORS } from './constants';
import { RiskIndicator, AnalysisSummary, RiskLevel } from './types';
import { GeminiService } from './services/geminiService';
import MetricCard from './components/MetricCard';
import BurryTerminal from './components/BurryTerminal';

const App: React.FC = () => {
  const [indicators, setIndicators] = useState<RiskIndicator[]>(INDICATORS);
  const [analysis, setAnalysis] = useState<AnalysisSummary | null>(null);
  const [loading, setLoading] = useState(false);
  const [lastUpdate, setLastUpdate] = useState<string>(new Date().toLocaleTimeString());

  const runAnalysis = useCallback(async () => {
    setLoading(true);
    const service = new GeminiService();
    const result = await service.analyzeRisk(indicators);
    if (result) {
      setAnalysis(result);
    }
    setLoading(false);
    setLastUpdate(new Date().toLocaleTimeString());
  }, [indicators]);

  useEffect(() => {
    runAnalysis();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const randomizeData = () => {
    setIndicators(prev => prev.map(ind => ({
      ...ind,
      value: Math.min(100, Math.max(0, ind.value + (Math.random() * 20 - 10)))
    })));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 min-h-screen">
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-8 mb-16">
        <div className="relative">
          <div className="flex items-center gap-3 mb-3">
            <span className="bg-red-500/20 text-red-500 text-[10px] font-bold px-3 py-1 rounded border border-red-500/30 tracking-widest animate-pulse uppercase">
              실시간 위기 모니터링 중
            </span>
          </div>
          <h1 className="text-6xl font-black tracking-tighter text-white flex items-center gap-4">
            BURRY<span className="text-red-500">SIGNAL</span>
          </h1>
          <p className="text-slate-400 mt-4 max-w-2xl text-lg font-light leading-relaxed">
            마이클 버리의 비관적 직관을 알고리즘화했습니다. 일반적인 지표가 아닌, <span className="text-blue-400 font-medium">부자들의 행동 변화와 언어적 패턴</span>을 통해 다음 붕괴를 예측합니다.
          </p>
        </div>
        
        <div className="flex flex-col items-end gap-6 bg-white/5 p-6 rounded-2xl border border-white/10 backdrop-blur-xl">
          <div className="text-right">
            <div className="text-slate-500 text-[10px] uppercase font-mono tracking-widest mb-1">마지막 분석 시간</div>
            <div className="text-3xl font-bold mono text-slate-100">{lastUpdate}</div>
          </div>
          <button 
            onClick={() => { randomizeData(); runAnalysis(); }}
            disabled={loading}
            className={`w-full px-8 py-4 rounded-xl font-bold text-sm tracking-widest uppercase transition-all flex items-center justify-center gap-3 ${
              loading 
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed' 
              : 'bg-red-600 hover:bg-red-500 text-white shadow-xl shadow-red-900/40 hover:-translate-y-1 active:translate-y-0'
            }`}
          >
            {loading ? '붕괴 징후 스캔 중...' : '데이터 재계산 및 분석'}
          </button>
        </div>
      </header>

      {/* Risk Legend Section */}
      <section className="mb-12 grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { level: 'STABLE', range: '0-30%', desc: '경제의 평온한 상태. 징후 없음.', color: 'text-green-500' },
          { level: 'WARNING', range: '31-60%', desc: '균열 발생. 내부자 이동 시작.', color: 'text-amber-500' },
          { level: 'CRISIS', range: '61-80%', desc: '시스템 붕괴 직전. 탈출 필요.', color: 'text-orange-600' },
          { level: 'CATASTROPHIC', range: '81-100%', desc: '총체적 붕괴. 즉각적 헤징 권장.', color: 'text-red-600' },
        ].map((item) => (
          <div key={item.level} className="bg-white/5 p-4 rounded-xl border border-white/5">
            <div className={`text-xs font-bold mb-1 ${item.color}`}>{item.level} ({item.range})</div>
            <div className="text-[11px] text-slate-400 leading-tight">{item.desc}</div>
          </div>
        ))}
      </section>

      <main className="space-y-16">
        {/* Main Indicators Grid */}
        <section>
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-sm font-mono tracking-[0.4em] uppercase text-slate-500">Unconventional_Risk_Metrics</h2>
            <div className="h-px flex-1 bg-gradient-to-r from-transparent via-white/10 to-transparent mx-8"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {indicators.map((indicator) => (
              <MetricCard key={indicator.id} indicator={indicator} />
            ))}
          </div>
        </section>

        {/* AI Analysis Section */}
        <section className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2">
             <div className="flex items-center gap-3 mb-6">
               <h2 className="text-sm font-mono tracking-[0.4em] uppercase text-slate-500">Burry_Deep_Scan_Result</h2>
               <div className="flex-1 h-px bg-white/10"></div>
             </div>
            <BurryTerminal analysis={analysis} loading={loading} />
          </div>
          
          <div className="space-y-8">
            <div className="glass rounded-2xl p-8 border-red-500/20 bg-gradient-to-br from-red-500/10 to-transparent">
              <h3 className="text-red-500 font-bold mb-6 flex items-center gap-3">
                <span className="animate-ping w-2 h-2 rounded-full bg-red-500"></span>
                실시간 위험 감지 로그
              </h3>
              <div className="space-y-6">
                <div className="p-5 bg-black/40 rounded-xl border border-white/5">
                  <div className="text-[10px] text-slate-500 mb-1 font-mono">전염 위험도 (R₀)</div>
                  <div className="text-3xl font-bold mono text-amber-500">1.84 <span className="text-xs font-normal text-slate-500 ml-2">임계값 초과</span></div>
                </div>
                <div className="p-5 bg-black/40 rounded-xl border border-white/5">
                  <div className="text-[10px] text-slate-500 mb-1 font-mono">유동성 은폐 계수</div>
                  <div className="text-3xl font-bold mono text-red-500">92% <span className="text-xs font-normal text-slate-500 ml-2">매우 높음</span></div>
                </div>
                <div className="pt-4 text-xs text-slate-400 leading-relaxed italic border-t border-white/5">
                  "모두가 주가 지수만 보고 있을 때, 저는 실리콘밸리의 이혼 서류와 런던의 중고 롤렉스 매물을 봅니다. 진짜 정보는 그곳에 있습니다."
                </div>
              </div>
            </div>

            <div className="glass rounded-2xl p-8 border-blue-500/20 bg-blue-500/5">
               <h3 className="text-blue-400 font-bold mb-6 uppercase tracking-widest text-sm">보조 데이터 스트림</h3>
               <div className="space-y-4 text-xs font-mono">
                 <div className="flex justify-between items-center py-2 border-b border-white/5">
                   <span className="text-slate-500">부실 채권 발행 속도</span>
                   <span className="text-red-400 font-bold">+18.5%</span>
                 </div>
                 <div className="flex justify-between items-center py-2 border-b border-white/5">
                   <span className="text-slate-500">최상위층 가계 부채</span>
                   <span className="text-amber-400 font-bold">위험 구간</span>
                 </div>
                 <div className="flex justify-between items-center py-2 border-b border-white/5">
                   <span className="text-slate-500">연준 의사록 불투명도</span>
                   <span className="text-red-400 font-bold">최대치</span>
                 </div>
                 <div className="flex justify-between items-center py-2">
                   <span className="text-slate-500">내부자 현금 비중</span>
                   <span className="text-green-400 font-bold">역대 최고</span>
                 </div>
               </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="mt-32 py-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 text-slate-600 text-[10px] tracking-widest uppercase font-mono">
        <div>© 2024 SCION_SIGNAL_INTEL - 투자 권고가 아니며 데이터 기반 시뮬레이션입니다.</div>
        <div className="flex gap-8">
          <span>처리 지연시간: 12ms</span>
          <span>가용성: 99.9%</span>
          <span>암호화: AES-4096-ECC</span>
        </div>
      </footer>
    </div>
  );
};

export default App;
